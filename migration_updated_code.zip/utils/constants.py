import streamlit as st

target_table_chunk_size = 30

model_max_tokens = 3900

excel_title_height = 40
excel_header_height = 20
excel_data_height = 20
max_header_weight = 60
min_header_weight = 20